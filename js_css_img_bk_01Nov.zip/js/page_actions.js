$(document).ready(function () {
    
    var type = "";
    var type_id = "";
    var section_id = "";
    var section_unid = "";
    
    $('#draggable-point').draggable({
        axis: 'x',
        containment: "#audio-progress"
    });

    $('#draggable-point').draggable({
        drag: function () {
            var offset = $(this).offset();
            var xPos = (100 * parseFloat($(this).css("left"))) / (parseFloat($(this).parent().css("width"))) + "%";

            $('#audio-progress-bar').css({
                'width': xPos
            });
        }
    });


    //input on change updating settings value object
    $("body").on('change',".setting_value_change", function () {
        console.log("here input changes trigger");
        console.log($(this));
        var type = $(this).attr('type');
        var input_id = $(this).attr('id');
        var parent_key = $.trim($(this).attr('parent-key'));
        var value = $(this).val();
        console.log(input_id);
        console.log(value);
        console.log(parent_key);
        var settings_for_id = $("#right-panel").attr('settings-for');
        var settings_pos = $("#right-panel").attr('settings-pos');
        var parent_type = $("#right-panel").attr('parent-type');
        console.log("settings for id " + settings_for_id);
        console.log("settings uid " + settings_pos);
        console.log("type " + type);

        if(parent_type =="section"){
            if (input_id == 'bg-color') {
                $("#main_container_preview" + settings_pos).css("background-color", value);
            }
            if (input_id == 'text-color') {
                $("#main_container_preview" + settings_pos).css("color", value);
            }
            if (input_id == 'border-color') {
                $("#main_container_preview" + settings_pos).css("border", "5px solid " + value);
            }
        }
        
        if(parent_type =="row"){
            if (input_id == 'bg-color') {
                $("#row-container-preview" + settings_pos).css("background-color", value);
            }
            if (input_id == 'text-color') {
                $("#row-container-preview" + settings_pos).css("color", value);
            }
            if (input_id == 'border-color') {
                $("#row-container-preview" + settings_pos).css("border", "5px solid " + value);
            }
        }
        
        


        var setting_values = $("#" + settings_for_id).attr('setting_values');
        console.log("setting values=="+setting_values);
        var objData = {}
        if (setting_values != "" && setting_values != 'undefined') {
            objData = JSON.parse(setting_values);
            console.log("setting values--");
            console.log(objData);

            if (objData.hasOwnProperty(parent_key)) {
                console.log("key present " + parent_key);
                console.log("key data " + objData[parent_key]);
                console.log("input id " + input_id);

                if (objData[parent_key].hasOwnProperty(input_id)) {
                    $.each(objData[parent_key], function (key, objvalue) {
                        console.log("key:" + key);
                        console.log("input id: " + input_id);
                        if (key == input_id) {
                            console.log(objData[parent_key][input_id]);
                            console.log(objData[parent_key][input_id]);
                            objData[parent_key][input_id] = value;
                        }
//                            console.log( key + ": " + value );
                    });
//                        objData.parent_key.input_id = value;

                } else {
                    console.log("in else ");//                        
                    objData[parent_key][input_id] = value;
                }
            } else {
                console.log("in parent key not present else ");
                //if key not present then create its object fist 
                if (objData[parent_key] == undefined) {
                    objData[parent_key] = {}
                }
                objData[parent_key][input_id] = value;
            }
        } else {
            console.log("in setting else ");
            //if key not present then create its object fist
            if (objData[parent_key] == undefined) {
                objData[parent_key] = {}
            }
            objData[parent_key][input_id] = value;
        }
        console.log(objData);
        console.log(JSON.stringify(objData));
        $("#" + settings_for_id).attr('setting_values', JSON.stringify(objData));
    });


    $("body").on('click',".openSettings", function () {
        var settings_for_id = $(this).attr('section-id');
        var settings_pos = $(this).attr('section-unid');
        var type = $(this).attr('type');
        if(type =="row"){
            settings_for_id = $(this).attr('row-id');
        }
        console.log(settings_for_id);
        $("#right-panel").removeClass('hide');

        $(".preview-div").addClass('hide');

        $("#right-panel").attr('settings-for', settings_for_id);
        $("#right-panel").attr('settings-pos', settings_pos);
        $("#right-panel").attr('parent-type', type);

        var setting_values = $(this).attr('setting_values');
        console.log("setting values=="+setting_values);
        
        if (setting_values != "" && setting_values != 'undefined') {
            var objData = JSON.parse(setting_values);
            console.log("setting values--");
            console.log(objData);
            $.each(objData, function (objkey, objvalue) {
                $.each(objvalue, function (inputkey, inputvalue) {
                    console.log("key:" + inputkey);
                    console.log("input id: " + inputvalue);
                    $("#" + inputkey).val(inputvalue);
                });
            });
        }
        

    });
    
    $("body").on('click',".deleteSection", function () {
        var unid = $(this).attr('section-unid');
        
        $.confirm({
            title: 'Confirm!',
            content: 'Are you sure you want to delete this section?',
            buttons: {
                continue: function () {
                    $("#main_container"+unid).remove();
                    $("#main_container_preview"+unid).remove();
                },
                cancel: function () {
                    $.alert('Canceled!');
                }
            }
        });

    });
    
    $("body").on('click',".deleteRow", function () {
        var unid = $(this).attr('row-unid');
        
        $.confirm({
            title: 'Confirm!',
            content: 'Are you sure you want to delete this row?',
            buttons: {
                continue: function () {
                    $("#row-container"+unid).remove();
                    $("#row-container-preview"+unid).remove();
                },
                cancel: function () {
                    $.alert('Canceled!');
                }
            }
        });

    });


    $("body").on('click',".add-new-section", function () { 
//        alert("here");
        var uniqueid = getUniqueId(); 
        console.log(uniqueid);
        var html = getSectionsHtml(uniqueid);
        var previewhtml = getSectionsPreviewHtml(uniqueid);
        console.log(html);
        $(html).appendTo(".container-body");
        $(previewhtml).appendTo(".preview-container-body");
    });
    
    
    $("body").on('click',".add-new-section-row", function () { 
//        alert("here");
        var uniqueid = getUniqueId(); 
        console.log(uniqueid);
        var html = getSectionsHtml(uniqueid);
        var previewhtml = getSectionsPreviewHtml(uniqueid);
        console.log(html);
        $(html).appendTo(".container-body");
        $(previewhtml).appendTo(".preview-container-body");
    });
    
    
    $("body").on('click',".upContainer", function () { 
        var unid = $(this).attr('section-unid');
        var parentDiv = $(this).closest('div.main_container');
        var parentDivPreview = $('#main_container_preview'+unid);
        console.log($(this).closest('div.main_container'));
        console.log($(this).closest('div.main_container').prev('div.main_container'));   
        
        console.log($(this).closest('div.main_container_preview'));
        console.log($(this).closest('div.main_container_preview').prev('div.main_container_preview'));    
        
        parentDiv.insertBefore( parentDiv.prev('div.main_container') )
        parentDivPreview.insertBefore( parentDivPreview.prev('div.main_container_preview') )
        
    });
    
    $("body").on('click',".downContainer", function () { 
        var unid = $(this).attr('section-unid');
        var parentDiv = $(this).closest('div.main_container');
        var parentDivPreview = $('#main_container_preview'+unid);
        console.log($(this).closest('div.main_container'));
        console.log($(this).closest('div.main_container').next('div.main_container'));
        
        console.log($(this).closest('div.main_container_preview'));
        console.log($(this).closest('div.main_container_preview').next('div.main_container_preview'));
        
        parentDiv.insertAfter(parentDiv.next('div.main_container'))
        parentDivPreview.insertAfter(parentDivPreview.next('div.main_container_preview'))
    });
    
    
    $("body").on('click',".upRowContainer", function () { 
        var unid = $(this).attr('row-unid');
        var row_id = $(this).attr('row-id');
        var parentDiv = $(this).closest('div.row-container');
        var parentDivPreview = $('#row-container-preview'+unid);
        
        console.log($(this).closest('div.row-container'));
        console.log($(this).closest('div.row-container').prev('div.row-container'));   
        
        console.log($(this).closest('div.row-container-preview'));
        console.log($(this).closest('div.row-container-preview').prev('div.row-container-preview'));    
        
        parentDiv.insertBefore( parentDiv.prev('div.row-container') );
        parentDivPreview.insertBefore( parentDivPreview.prev('div.row-container-preview') );
        
    });
    
    
    $("body").on('click',".downRowContainer", function () { 
        var unid = $(this).attr('row-unid');
        var row_id = $(this).attr('row-id');
        
        var parentDiv = $(this).closest('div.row-container');
        var parentDivPreview = $('#row-container-preview'+unid);
        
        console.log($(this).closest('div.row-container'));
        console.log($(this).closest('div.row-container').prev('div.row-container'));   
        
        console.log($(this).closest('div.row-container-preview'));
        console.log($(this).closest('div.row-container-preview').prev('div.row-container-preview'));    
        
        parentDiv.insertAfter(parentDiv.next('div.row-container'));
        parentDivPreview.insertAfter(parentDivPreview.next('div.row-container-preview'));
    });
    
    
    $("body").on('click',".add_row", function () { 
        
        var type = $(this).attr('type');
        var type_id = $(this).attr('type-id');
        var section_id = $(this).attr('section-id');
        var section_unid = $(this).attr('section-unid');
        var parent_div = $(this).attr('parent-div');
        var row_unid = $(this).attr('row-unid');
        
        $("#right-panel").addClass('hide');
        
        $("#choose_columns_dialog").attr("type",type);
        $("#choose_columns_dialog").attr("type-id",type_id);
        $("#choose_columns_dialog").attr("section-id",section_id);
        $("#choose_columns_dialog").attr("section-unid",section_unid);
        $("#choose_columns_dialog").attr("parent-div",parent_div);
        $("#choose_columns_dialog").attr("row-unid",row_unid);
        
        
        
        $('#addRowModal').modal('show');
        
    });

    //place columns to its appropriate 
//    $("body").on('click',"#choose_columns_dialog", function () { 
//        console.log("in add row columns");
//        var type = $(this).attr('type');
//        var type_id = $(this).attr('type-id');
//        var section_id = $(this).attr('section-id');
//        var section_unid = $(this).attr('section-unid');
//        var parent_div = $(this).attr('parent-div');
//        
//        console.log(type);
//        console.log(type_id);
//        console.log(section_id);
//        console.log(section_unid);
//        console.log("parent div "+parent_div);
//        var column_count = 2;
//        
//        var columnhtml = getColumnsHtml(column_count,section_unid,section_id);
//        var columnPreviewhtml = getRowColumnsPreviewHtml(column_count,section_unid,section_id);
//        
//        if(parent_div !="" && parent_div != 'undefined'){            
//            $(columnhtml).insertAfter("#"+parent_div+section_unid);
//            $(columnPreviewhtml).insertAfter("#row-container-preview"+section_unid);
//        }else{            
//            $(columnhtml).insertAfter("#"+type_id);
//            $(columnPreviewhtml).insertAfter("#add-row-preview"+section_unid);
//        }
//        
//
//        $("#add-row-preview"+section_unid).remove();
//        $("#"+type_id).remove();
//
//    });

    
    //open dialog for choose element   
    $("body").on('click',".add_column_element", function () { 
        console.log("here");
        var type = $(this).attr('type');
        var type_id = $(this).attr('type-id');
        var section_id = $(this).attr('section-id');
        var section_unid = $(this).attr('section-unid');
        var column = $(this).attr('column');
        
        console.log(type);
        console.log(type_id);
        console.log(section_id);
        console.log(section_unid);
        
        $("#right-panel").addClass('hide');
//        
        $("#choose_elements_dialog").attr("type",type);
        $("#choose_elements_dialog").attr("type-id",type_id);
        $("#choose_elements_dialog").attr("section-id",section_id);
        $("#choose_elements_dialog").attr("section-unid",section_unid);
        $("#choose_elements_dialog").attr("column",column);
        
        $(".element_div").attr("type",type);
        $(".element_div").attr("type-id",type_id);
        $(".element_div").attr("section-id",section_id);
        $(".element_div").attr("section-unid",section_unid);
        $(".element_div").attr("column",column);
        
        $('#addNewElement').modal('show');
        
    });
    
    
    //choose element and place to its aprropriate row
    $("body").on('click',".element_div", function () { 
        var type = $(this).attr('type');
        var type_id = $(this).attr('type-id');
        var section_id = $(this).attr('section-id');
        var section_unid = $(this).attr('section-unid');
        var template = $(this).attr('template');
        var column = $(this).attr('column');
        
        console.log(type_id);
        
        var elementhtml = getElementHtml(template,section_id);
        var elementPreviewhtml = getElementPreviewHtml(template,section_id);
        
        $(elementhtml).insertAfter("#"+type_id);
        $(elementPreviewhtml).insertAfter("#add-element-"+column+"-preview"+section_unid);
        

        $("#add-element-"+column+"-preview"+section_unid).remove();
        $("#"+type_id).remove();
        $('#addNewElement').modal('show');
    });
    
    $(".row-el").hover(
            function () {
                $('.section-el').addClass("hide-el");
            },
            function () {
                $('.section-el').removeClass("hide-el");
            }
    );
    //  $(".col-el").hover(
    //   function () {
    //     $('.row-el').addClass("hide-el");
    //   },
    //   function () {
    //     $('.row-el').removeClass("hide-el");
    //   }
    // );

    $(".col-inner").hover(
            function () {
                $(this).find('.col-el-edit').addClass("hide-el");
            },
            function () {
                $(this).find('.col-el-edit').removeClass("hide-el");
            }
    );

});

function getSectionsHtml(unid){
//    var section_settings_id = "section-el-settings"+unid;
    var sectionid = "section-el-settings"+unid;
    
    var html =' <div class="main_container" id="main_container'+unid+'" container-unid="'+unid+'"> '+
                '<section class="section-el" >'+
                    '<div class="col-add-el"  id="add-row'+unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                    '    <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                    '        <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                    '        <div class="col-el-edit1">'+
                    '            <a href="#" title="" class="add_row" type="row" type-id="add-row'+unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'" parent-div="" row-unid="">Add Row</a>'+
                    '        </div>'+
                    '    </div>'+
                    '</div>'+
                    '<div class="section-el-edit">'+
                    '    <div class="left-el">'+
                    '        <a href="#" title="" section-id="'+sectionid+'" section-unid="'+unid+'" class="upContainer" ><i class="fa-solid fa-arrow-up"></i></a>'+
                    '        <a href="#" title="" section-id="'+sectionid+'" section-unid="'+unid+'" class="downContainer" ><i class="fa-solid fa-arrow-down"></i></a>'+
                    '    </div>'+
                    '    <div class="right-el">'+
                    '        <a href="#" title="" id="'+sectionid+'" section-id="'+sectionid+'" section-unid="'+unid+'" type="section" class="openSettings" setting_values=""><i class="fa-solid fa-gear"></i></a>'+
                    '        <a href="#" title=""><i class="fa-regular fa-copy"></i></a>'+
                    '        <a href="#" title=""><i class="fa-regular fa-floppy-disk"></i></a>'+
                    '        <a href="#" title="" section-id="'+sectionid+'" section-unid="'+unid+'" class="deleteSection"><i class="fa-regular fa-trash-can"></i></a>'+
                    '    </div>'+
                    '    <div class="add-el">'+
                    '        <a href="#" class="add-new-section" type="section"  id="add-el'+unid+'" section-id="'+sectionid+'"  section-unid="'+unid+'" title="Add Section" ><i'+
                    '                class="fa-solid fa-plus"></i></a>'+
                    '    </div>'+
                    '</div>'+

                '</section>'+
            '</div>';
    
    return html;
    
}

function getSectionsPreviewHtml(unid){
    var sectionid = "preview-section-el"+unid;
    
    var html =' <div class="main_container_preview"  id="main_container_preview'+unid+'" container-unid="'+unid+'"> '+
                '<section class="section-el" id="'+sectionid+'">'+
                    '<div class="col-add-el"  id="add-row-preview'+unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'">'+
                    '    <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                    '           <div class="add-row-preview" type="row"></div>'+
                    '    </div>'+
                    '</div>'+                    

                '</section>'+
            '</div>';
    
    return html;
    
}


function getColumnsHtml(rowid_unid,column_count,unid,sectionid){
        
    var row_settings_id = "row-el-settings"+rowid_unid;    
        
    var html =' <div class="row-el row-container" id="row-container'+rowid_unid+'">'+
                '    <div class="col-el row">';
                
            if(column_count ==1){
                html +='<div class="col-add-el col-sm-12">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element"  id="add-element-1-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-1-'+rowid_unid+'"  column="1"  section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '            <div class="item-el-edit" >'+
                '               <div class="left-el">'+
                '                  <a href="#" title=""><i class="fa-solid fa-arrow-up"></i></a>'+
                '                  <a href="#" title=""><i class="fa-solid fa-arrow-down"></i></a>'+
                '              </div>'+
                '               <div class="right-el">'+
                '                  <a href="#" title=""><i class="fa-solid fa-gear"></i></a>'+
                '                  <a href="#" title=""><i class="fa-regular fa-copy"></i></a>'+
                '                  <a href="#" title=""><i class="fa-regular fa-floppy-disk"></i></a>'+
                '                  <a href="#" title=""><i class="fa-regular fa-trash-can"></i></a>'+
                '               </div>'+
                '               <div class="add-el">'+
                '                  <a href="" title="" data-bs-toggle="modal" data-bs-target="#exampleModal3"><i class="fa-solid fa-plus"></i></a>'+
                '               </div>'+
                '            </div>'+
                '       </div>';
                
            }    
                
            if(column_count ==2){
                                
                html +='<div class="col-add-el col-sm-6">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 " type="element"  id="add-element-1-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""   class="add_column_element" type="element" type-id="add-element-1-'+rowid_unid+'"  column="1"  section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-6">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element"  id="add-element-2-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-2-'+rowid_unid+'"   column="2" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>';
            }
            
            if(column_count ==3){
                                
                html +='<div class="col-add-el col-sm-4">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element"  id="add-element-1-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""   class="add_column_element" type="element" type-id="add-element-1-'+rowid_unid+'"  column="1" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-4">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element"  id="add-element-2-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-2-'+rowid_unid+'" column="2"  section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-4">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element"  id="add-element-3-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-3-'+rowid_unid+'" column="3"  section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>';
            }
            
            if(column_count ==4){
                                
                html +='<div class="col-add-el col-sm-3">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element" id="add-element-1-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""   class="add_column_element" type="element" type-id="add-element-1-'+rowid_unid+'"  column="1" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element" id="add-element-2-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-2-'+rowid_unid+'"  column="2" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element" id="add-element-3-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-3-'+rowid_unid+'"  column="3" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner">'+
                '                <span class="add-element"><i class="fa-solid fa-plus"></i></span>'+
                '                <div class="col-el-edit1 "  type="element" id="add-element-4-'+rowid_unid+'"  section-unid="'+sectionid+'" section-unid="'+unid+'">'+
                '                    <a href="#" title=""  class="add_column_element" type="element" type-id="add-element-4-'+rowid_unid+'"  column="4" section-id="'+sectionid+'" section-unid="'+unid+'" >Add Elements</a>'+
                '                </div>'+
                '            </div>'+
                '        </div>';
            }
                        
        
        html += '    </div>'+
                '    <div class="row-el-edit">'+
                '       <div class="left-el">'+
                '           <a href="#" title="" row-id="row-container'+rowid_unid+'" row-unid="'+rowid_unid+'" class="upRowContainer"><i class="fa-solid fa-arrow-up"></i></a>'+
                '           <a href="#" title="" row-id="row-container'+rowid_unid+'" row-unid="'+rowid_unid+'" class="downRowContainer"><i class="fa-solid fa-arrow-down"></i></a>'+
                '       </div>'+
                '       <div class="right-el">'+
                '           <a href="#" title="" id="'+row_settings_id+'" row-id="'+row_settings_id+'"  section-id="'+sectionid+'" section-unid="'+unid+'" type="row" class="openSettings"  setting_values=""><i class="fa-solid fa-gear"></i></a>'+
                '          <a href="#" title=""><i class="fa-regular fa-copy"></i></a>'+
                '          <a href="#" title=""><i class="fa-regular fa-floppy-disk"></i></a>'+
                '          <a href="#" title="" row-id="row-container'+rowid_unid+'" row-unid="'+rowid_unid+'" class="deleteRow"><i class="fa-regular fa-trash-can"></i></a>'+
                '      </div>'+
                '      <div class="add-el Dipali">'+
                '         <a href="#" title="" class="add_row" type="row" add-type="same-section" type-id="add-row'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'" parent-div="row-container"  row-unid="'+rowid_unid+'"><i class="fa-solid fa-plus"></i></a>'+
                '     </div>'+
                '    </div>'+
                '</div>';
        
        return html;        
    
}



function getRowColumnsPreviewHtml(rowid_unid,column_count,unid,sectionid){
//    var sectionid = "preview-row-el"+unid;
//    
//    var row_settings_id = "row-el-settings"+unid;    
//        
    var html =' <div class="row-el row-container-preview" id="row-container-preview'+rowid_unid+'">'+
                '    <div class="col-el row">';
                
            if(column_count ==1){
                html +='<div class="col-add-el col-sm-12">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-1-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>';
                
            }    
                
            if(column_count ==2){
                                
                html +='<div class="col-add-el col-sm-6">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-1-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-6">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-2-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>';
            }
            
            if(column_count ==3){
                                
                html +='<div class="col-add-el col-sm-4">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-1-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-4">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-2-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-4">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-3-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>';
            }
            
            if(column_count ==4){
                                
                html +='<div class="col-add-el col-sm-3">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-1-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-2-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-3-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>'+
                '        <div class="col-add-el col-sm-3">'+
                '            <div class="col-inner bg-danger" style="background-color: #ccc !important">'+
                '               <div class="add-row-preview" type="row" id="add-element-4-preview'+rowid_unid+'"  section-id="'+sectionid+'" section-unid="'+unid+'"></div>'+
                '            </div>'+
                '        </div>';
            }
                        
        
        html += '    </div>'+
                '</div>';
        
        return html; 
    
}


function getElementHtml(template,id){
    
    var html = '';
    if(template == "tem_headline"){
        html +='<h1 class="ne elHeadline hsSize3 lh4 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center;font-size: 32px" data-bold="inherit" data-gramm="false" contenteditable="false">'+
                '<b>Large Call to Action Headline</b>'+
              '</h1>';
    }
    if(template == "tem_sub_headline"){
        html +='<h2 class="ne elHeadline hsSize2 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center;font-size: 23px" data-bold="inherit" data-gramm="false">'+
                '   Small Call to Action Headline'+
                '</h2>';
    }
    if(template == "tem_paragraph"){
        html +='<p>'+
                '   P Tag'+
                '</p>';
    }
    
    return html; 
}

function getElementPreviewHtml(template,id){
    
    var html = '';
    if(template == "tem_headline"){
        html +='<h1 class="ne elHeadline hsSize3 lh4 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center;font-size: 32px" data-bold="inherit" data-gramm="false" contenteditable="false">'+
                '<b>Large Call to Action Headline</b>'+
              '</h1>';
    }
    if(template == "tem_sub_headline"){
        html +='<h2 class="ne elHeadline hsSize2 lh3 elMargin0 elBGStyle0 hsTextShadow0" style="text-align: center;font-size: 23px" data-bold="inherit" data-gramm="false">'+
                '   Small Call to Action Headline'+
                '</h2>';
    }
    
    return html; 
}


function getUniqueId(){
    var uniq = (new Date()).getTime();
    return uniq;
}

function setColor(type,parent_key,id,event){
    console.log("here input changes trigger");
        console.log($(this));
        var type = type;
        var input_id = id;
        var parent_key = parent_key;
        var value = event.value;
        console.log(input_id);
        console.log(value);
        console.log(parent_key);
        var settings_for_id = $("#right-panel").attr('settings-for');
        var settings_pos = $("#right-panel").attr('settings-pos');
        var parent_type = $("#right-panel").attr('parent-type');
        console.log("settings for id " + settings_for_id);
        console.log("settings uid " + settings_pos);
        console.log("type " + type);

        if(parent_type =="section"){
            if (input_id == 'bg-color') {
                $("#main_container_preview" + settings_pos).css("background-color", value);
                $("#main_container" + settings_pos).css("background-color", value);
            }
            if (input_id == 'text-color') {
                $("#main_container_preview" + settings_pos).css("color", value);
                $("#main_container" + settings_pos).css("color", value);
            }
            if (input_id == 'border-color') {
                $("#main_container_preview" + settings_pos).css("border", "5px solid " + value);
                $("#main_container" + settings_pos).css("border", "5px solid " + value);
            }
        }
        
        if(parent_type =="row"){
            if (input_id == 'bg-color') {
                $("#row-container-preview" + settings_pos).css("background-color", value);
                $("#row-container" + settings_pos).css("background-color", value);
            }
            if (input_id == 'text-color') {
                $("#row-container-preview" + settings_pos).css("color", value);
                $("#row-container" + settings_pos).css("color", value);
            }
            if (input_id == 'border-color') {
                $("#row-container-preview" + settings_pos).css("border", "5px solid " + value);
                $("#row-container" + settings_pos).css("border", "5px solid " + value);
            }
        }
        
        


        var setting_values = $("#" + settings_for_id).attr('setting_values');
        console.log("setting values=="+setting_values);
        var objData = {}
        if (setting_values != "" && setting_values != 'undefined') {
            objData = JSON.parse(setting_values);
            console.log("setting values--");
            console.log(objData);

            if (objData.hasOwnProperty(parent_key)) {
                console.log("key present " + parent_key);
                console.log("key data " + objData[parent_key]);
                console.log("input id " + input_id);

                if (objData[parent_key].hasOwnProperty(input_id)) {
                    $.each(objData[parent_key], function (key, objvalue) {
                        console.log("key:" + key);
                        console.log("input id: " + input_id);
                        if (key == input_id) {
                            console.log(objData[parent_key][input_id]);
                            console.log(objData[parent_key][input_id]);
                            objData[parent_key][input_id] = value;
                        }
//                            console.log( key + ": " + value );
                    });
//                        objData.parent_key.input_id = value;

                } else {
                    console.log("in else ");//                        
                    objData[parent_key][input_id] = value;
                }
            } else {
                console.log("in parent key not present else ");
                //if key not present then create its object fist 
                if (objData[parent_key] == undefined) {
                    objData[parent_key] = {}
                }
                objData[parent_key][input_id] = value;
            }
        } else {
            console.log("in setting else ");
            //if key not present then create its object fist
            if (objData[parent_key] == undefined) {
                objData[parent_key] = {}
            }
            objData[parent_key][input_id] = value;
        }
        console.log(objData);
        console.log(JSON.stringify(objData));
        $("#" + settings_for_id).attr('setting_values', JSON.stringify(objData));
}

function addHeadParaElement(event,template){
    alert("Add element clicked");
    var type = $("#choose_elements_dialog").attr('type');
        var type_id = $("#choose_elements_dialog").attr('type-id');
        var section_id = $("#choose_elements_dialog").attr('section-id');
        var section_unid = $("#choose_elements_dialog").attr('section-unid');
//        var template = $("#choose_elements_dialog").attr('template');
        var column = $("#choose_elements_dialog").attr('column');
        
        console.log(type_id);
        
        var elementhtml = getElementHtml(template,section_id);
        var elementPreviewhtml = getElementPreviewHtml(template,section_id);
        
        $(elementhtml).insertAfter("#"+type_id);
        $(elementPreviewhtml).insertAfter("#add-element-"+column+"-preview"+section_unid);
        

        $("#add-element-"+column+"-preview"+section_unid).remove();
        $("#"+type_id).remove();
        $('#addNewElement').modal('hide');
}

function addColumns(event,count){
    console.log("in add row columns");
    var type = $("#choose_columns_dialog").attr('type');
    var type_id = $("#choose_columns_dialog").attr('type-id');
    var section_id = $("#choose_columns_dialog").attr('section-id');
    var section_unid = $("#choose_columns_dialog").attr('section-unid');
    var parent_div = $("#choose_columns_dialog").attr('parent-div');
    var row_unid = $("#choose_columns_dialog").attr('row-unid');

    console.log(type);
    console.log(type_id);
    console.log(section_id);
    console.log(section_unid);
    console.log("parent div "+parent_div);
    console.log("row unid "+row_unid);
    
    var column_count = count;
    var uniqueid = getUniqueId();

    var columnhtml = getColumnsHtml(uniqueid,column_count,section_unid,section_id);
    var columnPreviewhtml = getRowColumnsPreviewHtml(uniqueid,column_count,section_unid,section_id);

    if(parent_div ==""){        
        console.log("parent div not present");
        $(columnhtml).insertAfter("#"+type_id);
        $(columnPreviewhtml).insertAfter("#add-row-preview"+section_unid);
    }else{                    
        console.log("parent div prresent");
        $(columnhtml).insertAfter("#"+parent_div+row_unid);
        $(columnPreviewhtml).insertAfter("#row-container-preview"+row_unid);
    }


//    $(columnhtml).insertAfter("#"+type_id);
//    $(columnPreviewhtml).insertAfter("#add-row-preview"+section_unid);


    $("#add-row-preview"+section_unid).remove();
    $("#"+type_id).remove();
    
    $('#addRowModal').modal('hide');
}